clear;
clc;
A = xlsread("Book1.xlsx",'Sheet2');
kx = 1;
t = linspace(0,2*pi/kx*3,1000);
figure(1)
x1 = A(1:end/3,1);
y1 = A(1:end/3,2);
[X,T] = meshgrid(x1,t);
for i=1:length(x1)
    for j=1:length(t)
        z(i,j) = y1(i)*real(exp(1i*kx*t(j)));
    end
end
imagesc(x1,t,z);
hold on;
cp = redblue(1000);
colormap(cp);
axis off;
set(gcf,'PaperUnits','inches','PaperPosition',[0 0 3 9])
ax = gca;
outerpos = ax.OuterPosition;
ti = ax.TightInset; 
left = outerpos(1) + ti(1);
bottom = outerpos(2) + ti(2);
ax_width = outerpos(3) - ti(1) - ti(3);
ax_height = outerpos(4) - ti(2) - ti(4);
ax.Position = [left bottom ax_width ax_height];
print(gcf,'-r1200','-dpng','./disp11');

figure(2)
x1 = A(end/3+1:end/3*2,1);
y1 = A(end/3+1:end/3*2,2);
[X,T] = meshgrid(x1,t);
for i=1:length(x1)
    for j=1:length(t)
        z(i,j) = y1(i)*real(exp(1i*kx*t(j)));
    end
end
imagesc(x1,t,z);
hold on;
cp = redblue(1000);
colormap(cp);
axis off;
set(gcf,'PaperUnits','inches','PaperPosition',[0 0 3 9])
ax = gca;
outerpos = ax.OuterPosition;
ti = ax.TightInset; 
left = outerpos(1) + ti(1);
bottom = outerpos(2) + ti(2);
ax_width = outerpos(3) - ti(1) - ti(3);
ax_height = outerpos(4) - ti(2) - ti(4);
ax.Position = [left bottom ax_width ax_height];
print(gcf,'-r1200','-dpng','./disp12');

figure(3)
x1 = A(end/3*2+1:end,1);
y1 = A(end/3*2+1:end,2);
[X,T] = meshgrid(x1,t);
for i=1:length(x1)
    for j=1:length(t)
        z(i,j) = y1(i)*real(exp(1i*kx*t(j)));
    end
end
imagesc(x1,t,z);
hold on;
cp = redblue(1000);
colormap(cp);
axis off;
set(gcf,'PaperUnits','inches','PaperPosition',[0 0 6 6])
ax = gca;
outerpos = ax.OuterPosition;
ti = ax.TightInset; 
left = outerpos(1) + ti(1);
bottom = outerpos(2) + ti(2);
ax_width = outerpos(3) - ti(1) - ti(3);
ax_height = outerpos(4) - ti(2) - ti(4);
ax.Position = [left bottom ax_width ax_height];
colorbar;
hcb=colorbar;
set(hcb,'YTick',[])
print(gcf,'-r1200','-dpng','./disp14');

% exportgraphics(gcf,'disp.png','BackgroundColor','none','Resolution',300)