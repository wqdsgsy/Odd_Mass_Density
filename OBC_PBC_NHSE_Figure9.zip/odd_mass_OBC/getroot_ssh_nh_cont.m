function rt0 = getroot_ssh_nh_cont(lambda,mu,rho_x,rho_y,beta,k_x,w,EE)
    E = EE(1)+EE(2)*1i;
    E0 = mu*(3*lambda+2*mu)/(lambda+mu);
    nu = lambda/(lambda+mu)/2;
    rho_xy = beta*(rho_x+rho_y)/2;
    p = [E0^2/2 - (E0^2*nu)/2, 0, ...
         E0^2*k_x^2 - E0^2*k_x^2*nu - E0*E^2*rho_x - (E0*E^2*rho_y)/2 + (E0*E^2*nu*rho_y)/2 + E0*E^2*nu^2*rho_x + (E0*E^2*nu^2*rho_y)/2 - (E0*E^2*nu^3*rho_y)/2, ...
         (E0*E^2*k_x*rho_xy)/2 + (E0*E^2*k_x*nu*rho_xy)/2 - (E0*E^2*k_x*nu^2*rho_xy)/2 - (E0*E^2*k_x*nu^3*rho_xy)/2,...
         (E0^2*k_x^4)/2 - (E0^2*k_x^4*nu)/2 + E^4*rho_x*rho_y - (E0*E^2*k_x^2*rho_x)/2 - E0*E^2*k_x^2*rho_y - 2*E^4*nu^2*rho_x*rho_y + E^4*nu^4*rho_x*rho_y + (E0*E^2*k_x^2*nu^2*rho_x)/2 + E0*E^2*k_x^2*nu^2*rho_y - (E0*E^2*k_x^2*nu^3*rho_x)/2 + (E0*E^2*k_x^2*nu*rho_x)/2];
    p = p/E0^2;
    rt = sort(imag(roots(p)));
    rt0 = rt(2) - rt(3);
end