function y = root_obc_ssh(lambda,mu,rho_x,rho_y,beta,k_x,h,EE)
 E = EE(1)+1i*EE(2);
 rho_xy = beta*(rho_x+rho_y)/2;
 E0 = mu*(3*lambda+2*mu)/(lambda+mu);
 nu = lambda/(lambda+mu)/2;
 p = [E0^2/2 - (E0^2*nu)/2, 0, ...
     E0^2*k_x^2 - E0^2*k_x^2*nu - E0*E^2*rho_x - (E0*E^2*rho_y)/2 + (E0*E^2*nu*rho_y)/2 + E0*E^2*nu^2*rho_x + (E0*E^2*nu^2*rho_y)/2 - (E0*E^2*nu^3*rho_y)/2, ...
     (E0*E^2*k_x*rho_xy)/2 + (E0*E^2*k_x*nu*rho_xy)/2 - (E0*E^2*k_x*nu^2*rho_xy)/2 - (E0*E^2*k_x*nu^3*rho_xy)/2,...
     (E0^2*k_x^4)/2 - (E0^2*k_x^4*nu)/2 + E^4*rho_x*rho_y - (E0*E^2*k_x^2*rho_x)/2 - E0*E^2*k_x^2*rho_y - 2*E^4*nu^2*rho_x*rho_y + E^4*nu^4*rho_x*rho_y + (E0*E^2*k_x^2*nu^2*rho_x)/2 + E0*E^2*k_x^2*nu^2*rho_y - (E0*E^2*k_x^2*nu^3*rho_x)/2 + (E0*E^2*k_x^2*nu*rho_x)/2];
 p = p/E0^2;
 if isnan(real(p(4)))
    y(1) = NaN;
    y(2) = NaN;
    return;
 end
 q = roots(p);
 dt = zeros(4);
 u = zeros(4,1);
 v = zeros(4,1);
 for i=1:4
     k_y = q(i);
     u(i) = (1+nu)/2*k_x*k_y-E^2*(1-nu^2)/E0*rho_x;
     v(i) = k_x^2 + (1-nu)/2*(k_y)^2 - E^2*(1-nu^2)/E0*rho_x;
     d = sqrt(u(i)^2+v(i)^2);
     u(i) = u(i)/d;
     v(i) = v(i)/d;
     dt(1,i) = nu*k_x*u(i) + k_y*v(i);
     dt(2,i) = k_y*u(i) + k_x*v(i);
     dt(3,i) = ( nu*k_x*u(i) + k_y*v(i) )*exp(1i*k_y*h);
     dt(4,i) = ( k_y*u(i) + k_x*v(i) )*exp(1i*k_y*h);
 end
 ddt = det(dt);
 y(1) = real(ddt);
 y(2) = imag(ddt);
end
