clear;
% z2 = load("z3.mat").z3;
lambda = 37e9;
mu = 27.4e9;
rho_x = 16277;
rho_y = 16277;
E0 = mu*(3*lambda+2*mu)/(lambda+mu);
nu = lambda/(lambda+mu)/2;
beta = 0.2;
k_x = 1;
rho_xy = beta*(rho_x+rho_y)/2;
w = 148e-3;
% h = 3*w;
ky = linspace(-4,4,15);
% ky = z2;

j=0;
om = [];
for i=1:length(ky)
%     if real(ky(i))<0 
        j = j+1;
        k_y = ky(i);
        s = (1-nu^2)/E0;
        K = [k_x^2+(1-nu)/2*k_y^2, (1+nu)/2*k_x*k_y;
            (1+nu)/2*k_x*k_y, k_y^2+(1-nu)/2*k_x^2];
        M = [rho_x,rho_xy;0,rho_y]*s;
        z = eig(K,M);
        z = sqrt(z)/1e3;
        z = sort(z,'ComparisonMethod','real');
        om(:,j) = z;
%     end
%     p = [rho_x*rho_y*nu^4 - 2*rho_x*rho_y*nu^2 + rho_x*rho_y, ...
%         0, (E0*k_x^2*nu*rho_x)/2 - E0*k_x^2*rho_y - E0*k_y^2*rho_x - (E0*k_y^2*rho_y)/2 - (E0*k_x^2*rho_x)/2 + (E0*k_y^2*nu*rho_y)/2 + (E0*k_x^2*nu^2*rho_x)/2 + E0*k_x^2*nu^2*rho_y - (E0*k_x^2*nu^3*rho_x)/2 + E0*k_y^2*nu^2*rho_x + (E0*k_y^2*nu^2*rho_y)/2 - (E0*k_y^2*nu^3*rho_y)/2 + (E0*k_x*k_y*rho_xy)/2 + (E0*k_x*k_y*nu*rho_xy)/2 - (E0*k_x*k_y*nu^2*rho_xy)/2 - (E0*k_x*k_y*nu^3*rho_xy)/2, ...
%         0, (E0^2*k_x^4)/2 + (E0^2*k_y^4)/2 - (E0^2*k_x^4*nu)/2 - (E0^2*k_y^4*nu)/2 + E0^2*k_x^2*k_y^2 - E0^2*k_x^2*k_y^2*nu];
%     om(:,i) = roots(p)/1e3;
end
figure(2)
plot(real(om(1,:))*2*pi,imag(om(1,:))*2*pi,'linewidth',3,'color','r');
% xlim([0,110])
hold on;
plot(real(om(2,:))*2*pi,imag(om(2,:))*2*pi,'linewidth',3,'color','r');
% xlim([0,110])
hold on;
plotColors = jet(length(ky));
for i=1:length(ky)
    plot(real(om(:,i))*2*pi,imag(om(:,i))*2*pi,'s','MarkerSize',16,'MarkerFaceColor',plotColors(i,:),'MarkerEdgeColor','none');
    % xlim([0,110])
    hold on;
end

% plot(real(om(1,:))*2*pi,imag(om(1,:))*2*pi-0.2,'linewidth',3,'color','r');
% % xlim([0,110])
% hold on;
% plot(real(om(2,:))*2*pi,imag(om(2,:))*2*pi-0.2,'linewidth',3,'color','r');
% % xlim([0,110])
% hold on;
% plotColors = jet(length(ky));
% for i=1:length(ky)
%     plot(real(om(:,i))*2*pi,imag(om(:,i))*2*pi-0.2,'s','MarkerSize',16,'MarkerFaceColor',plotColors(i,:),'MarkerEdgeColor','none');
%     % xlim([0,110])
%     hold on;
% end

set(gca,'LineWidth',3,'FontSize',32)
xlabel('\Re (frequency) (kHz)');
ylabel('\Im (frequency) (kHz)');
xlim([0,50]);
yticks(-1:1:1);
ylim([-1,1]);
% set(gcf,'PaperUnits','inches','PaperPosition',[0 0 12 9])
% print(gcf,'-r600','-dpng','./pbc');
% set(xl,'Interpreter','latex');
% set(yl,'Interpreter','latex');
