%%OBC
clear;
clc;
A = xlsread("Book1.xlsx");
x1 = A(:,6);
y1 = A(:,7);
j = 0;
for i=1:10:length(x1)
    j = j+1;
    x0(j) = x1(i);
    y0(j) = y1(i);
end
figure(2)
plot(x0/1e3*2*pi,y0/1e3*2*pi,'.','color',[1 1 1]*0.7,'MarkerSize',40);
hold on;
%%
% open('untitled2.fig');
% a = get(gca,'Children');
% xdata = get(a, 'XData');
% ydata = get(a, 'YData');
% figure(2)
% plot(xdata*2*pi,ydata*2*pi,'b.','MarkerSize',10);
% hold on;
% set(gca,'LineWidth',3,'FontSize',32)
% xlabel('\Re (frequency) (kHz)');
% ylabel('\Im (frequency) (kHz)');
% xlim([5,50]);
% ylim([-1,1]);

figure(2)
hh(1)=plot(-100,0,'-s','MarkerSize',10,'MarkerFaceColor','r','MarkerEdgeColor','none');
hold on;
hh(2)=plot(-100,0,'.','color',[1 1 1]*0.7,'MarkerSize',30);
hold on;
legend(hh,{'PBC','OBC'});
set(gca,'fontsize',32,'linewidth',3)
set(gcf,'PaperUnits','inches','PaperPosition',[0 0 10 7.5])
print(gcf,'-r600','-dpng','./pbc_vs_obc1');