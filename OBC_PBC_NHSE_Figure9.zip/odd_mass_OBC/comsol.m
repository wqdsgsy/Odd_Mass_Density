%%OBC
clear;
clc;
A = xlsread("Book1.xlsx");
x1 = A(:,2);
y1 = A(:,3);
figure(2)
plot(x1/1e3*2*pi,y1/1e3*2*pi,'.','color',[1 1 1]*0.7,'MarkerSize',30);
hold on;
%%
% open('untitled.fig');
% a = get(gca,'Children');
% xdata = get(a, 'XData');
% ydata = get(a, 'YData');
% for i=1:length(xdata)
%     x = xdata(i);
%     y = ydata(i);
%     x = cell2mat(x)*2*pi;
%     y = cell2mat(y)*2*pi;
%     figure(2)
%     plot(x,y,'b.','MarkerSize',10);
%     hold on;
% end
% set(gca,'LineWidth',3,'FontSize',28)
xlabel('\Re (frequency) (kHz)');
ylabel('\Im (frequency) (kHz)');
xlim([5,50]);
ylim([-4.5,4.5]);

figure(2)
hh(1)=plot(-100,0,'-s','MarkerSize',10,'MarkerFaceColor','r','MarkerEdgeColor','none');
hold on;
hh(2)=plot(-100,0,'.','color',[1 1 1]*0.7,'MarkerSize',30);
hold on;
% hh(3)=plot([0,0.1],[0,0.1],'b-','LineWidth',3);
% hold on;
% legend(hh,{'PBC','OBC'});
set(gca,'fontsize',32,'linewidth',3)
set(gcf,'PaperUnits','inches','PaperPosition',[0 0 10 7.5])
print(gcf,'-r600','-dpng','./pbc_vs_obc');